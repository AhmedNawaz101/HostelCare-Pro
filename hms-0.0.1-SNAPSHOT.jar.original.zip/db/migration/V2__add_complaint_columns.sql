ALTER TABLE complaints
  ADD COLUMN IF NOT EXISTS tracking_id VARCHAR(50) UNIQUE NOT NULL DEFAULT concat('HMS-', substring(md5(random()::text), 1, 8));

ALTER TABLE complaints
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

-- ensure existing rows get a tracking id if missing
UPDATE complaints SET tracking_id = concat('HMS-', substring(md5(random()::text), 1, 8)) WHERE tracking_id IS NULL;

-- set updated_at for existing rows
UPDATE complaints SET updated_at = created_at WHERE updated_at IS NULL;